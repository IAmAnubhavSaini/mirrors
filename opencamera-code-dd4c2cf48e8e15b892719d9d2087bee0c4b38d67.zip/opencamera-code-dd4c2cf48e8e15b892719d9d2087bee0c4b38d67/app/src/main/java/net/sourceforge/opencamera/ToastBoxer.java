package net.sourceforge.opencamera;

import android.widget.Toast;

/** Allows methods to update a Toast with a new Toast.
 */
public class ToastBoxer {
    public Toast toast;

    public ToastBoxer() {
    }
}
